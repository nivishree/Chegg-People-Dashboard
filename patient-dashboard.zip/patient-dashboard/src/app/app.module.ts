import {MatInputModule} from '@angular/material/input';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardHeaderComponent } from './components/dashboard-header/dashboard-header.component';
import { SubHeaderComponent } from './components/sub-header/sub-header.component';
import { SearchBarComponent } from './components/search-bar/search-bar.component';
// import { DashboardHeaderComponent } from './dashboard-header/dashboard-header.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeletePatientComponent } from './components/delete-patient/delete-patient.component';
import { AddComponentComponent } from './components/add-component/add-component.component';
import { HttpClientModule } from '@angular/common/http';
import { SearchComponent } from './components/search/search.component';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
@NgModule({
  declarations: [
    AppComponent,
    DashboardHeaderComponent,
    SubHeaderComponent,
    SearchBarComponent,
    DeletePatientComponent,
    AddComponentComponent,
    SearchComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    MatDialogModule,
    MatSnackBarModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  exports:[
    DeletePatientComponent
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [DeletePatientComponent]
})
export class AppModule { }
