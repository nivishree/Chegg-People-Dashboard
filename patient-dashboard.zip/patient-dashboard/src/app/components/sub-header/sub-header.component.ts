import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeletePatientComponent } from '../delete-patient/delete-patient.component';
import { AddComponentComponent } from '../add-component/add-component.component';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.scss']
})
export class SubHeaderComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  openDelete() {

    this.dialog.open(DeletePatientComponent);
  }
  openAdd() {
    this.dialog.open(AddComponentComponent);
  }
  Search() {
    this.dialog.open(SearchComponent);
  }

  ngOnInit(): void {
  }

}
function AddComponent(AddComponent: any) {
  throw new Error('Function not implemented.');
}

