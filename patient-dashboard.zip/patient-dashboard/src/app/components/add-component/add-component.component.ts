import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-add-component',
  templateUrl: './add-component.component.html',
  styleUrls: ['./add-component.component.scss']
})
export class AddComponentComponent implements OnInit {
  public obs: Observable<any> | undefined;
  firstname: string = '';
  lastname: string = '';
  designation: string = '';
  school: string = '';
  email: string = '';
  courses: string = '';
  baseURL: String = "http://localhost:8080/Chegg/api/"
  constructor(private http: HttpClient) { }

  isVisible: any;
  isSelected: boolean = true;
  ngOnInit(): void {

  }

  adduser(): Observable<any> {
    if (this.isVisible == 1) {
      this.designation = "professor";
    } else {
      this.designation = "student";
    }
    const user = {
      "schoolName": this.school,
      "email": this.email,
      "designation": this.designation,
      "coursesTaught": this.courses,
      "firstName": this.firstname,
      "lastName": this.lastname
    };
    console.log(user);
    console.log(this.designation);
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('accept', 'application/json');
    const body = JSON.stringify(user);
    console.log(body)
    this.obs = this.http.post(this.baseURL + this.designation, user, { 'headers': headers });
    window.location.reload();
    this.obs.subscribe(data => console.log(data));
    return this.obs;
  }

  Update() {

    const user: any = {
      "lastName": this.lastname
    };
    if (this.school != '') {
      user["schoolName"] = this.school;
    }
    if (this.email != '') {
      user["email"] = this.email;
    }

    if (this.courses != '') {
      user["coursesTaught"] = this.courses;
    }
    if (this.firstname != '') {
      user["firstName"] = this.firstname;
    }

    const headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    headers.append('accept', 'application/json');
    const body = JSON.stringify(user);
    console.log(body)
    this.obs = this.http.put(this.baseURL + "update/" + this.lastname, user, { 'headers': headers });
    window.location.reload();
    this.obs.subscribe(data => console.log(data));
    return this.obs;

  }
}

