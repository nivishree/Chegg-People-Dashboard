import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Observable } from 'rxjs';

import { DeletePatientComponent } from '../delete-patient/delete-patient.component';
import { DataService } from '../../services/data.service';
@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss']
})
export class SearchBarComponent implements OnInit {
  obs: Observable<any> | undefined;
  isAccepted: boolean = true;
  Items: any = [];
  school: string | undefined;
  constructor(private dataService: DataService) {

  }

  ngOnInit() {
    this.dataService.fetchData().subscribe((res: any[]) => {
      this.Items = res;
    })
  }

}
