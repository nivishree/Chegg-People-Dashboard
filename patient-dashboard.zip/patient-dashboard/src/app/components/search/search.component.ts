import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
Schoolvalues:any =[];
Items:any = [];
School = "";
Designation = "";
  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.dataService.fetchData().subscribe((res: any[]) => {
      this.Schoolvalues = res;
    })
}
change() {
  this.dataService.fetchDataWithFilter(this.Designation, this.School).subscribe((res: any[]) => {
    this.Items = res;
  });
  // window.location.reload();
}

}
