import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-delete-patient',
  templateUrl: './delete-patient.component.html',
  styleUrls: ['./delete-patient.component.scss']
})
export class DeletePatientComponent implements OnInit {
  id: String = '';
  public obs: Observable<any> | undefined;
  baseURL: String = "http://localhost:8080/Chegg/api/"
  constructor(private snackBar: MatSnackBar, private http: HttpClient) { }
  openSnackBar(message: string, action: any) {
    this.obs = this.http.delete(this.baseURL + 'delete/' + Number(this.id));
    this.obs.subscribe(data => console.log(data));
    let snackBarRef = this.snackBar.open(message, action, { duration: 1500 });
    snackBarRef.afterDismissed().subscribe(() => {
      console.log("delete snack bar is dismissed");
    });
    snackBarRef.onAction().subscribe(() => {
      console.log("delete snack bar is in action");
    });
    window.location.reload();
  }

  ngOnInit(): void {
  }

}
