import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class DataService {

  private api = "http://localhost:8080/Chegg/api";

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  constructor(private httpClient: HttpClient) { }

  fetchData(): Observable<any[]> {
    return this.httpClient.get<any[]>(this.api + '/users/');
  }
  // search/Student/All
  fetchDataWithFilter(desig: string, school: string): Observable<any[]> {
    return this.httpClient.get<any[]>(this.api + '/search/' + desig + '/' + school);
  }

}